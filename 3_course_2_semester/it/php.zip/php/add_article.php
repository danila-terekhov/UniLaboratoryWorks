<!DOCKTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html">
<meta http-equiv="Content-Language" content="en-us">
<title>Login</title>
<link rel=stylesheet href="style.css" type="text/css">
</head>
<body>
	<div class="wrapper">
		<div class="header">Header</div>
		<div class="content-login">
<form id="logoForm" action="after_article_add.php" name="misc" method="post">
 <fieldset>
 <legend>Article</legend>
<label for="title">Title</label> 
<input name="title" autofocus required ><br>
<textarea name="article" rows="5" cols="80" >
</textarea>
</fieldset>
<p>
<input type="submit" name="finish" ></p>
</form>
		</div>
			<div class="clear"></div>
		<div class="footer">Footer</div>
	</div>

</body>
</html>
