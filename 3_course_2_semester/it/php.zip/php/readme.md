1. add dynamic titles
2. add insert script
